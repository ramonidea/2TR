angular.module('app.services', [])

.factory('Cred', function() {

  cred = {};
  cred.name = "";
  cred.email = "";
  cred.login = false;
  cred.grade = "";
  cred.Tutor = false;
  cred.User = false;
  return {

    getCred: function () {
      return cred;
    },
    setCred: function (authObject) {
      cred = authObject;
    },
    reset: function(){
      cred = {};
      cred.name = "Guest";
      cred.email = "";
      cred.login = false;
      cred.grade = "";
      cred.Tutor = false;
      cred.User = true;
    }
  };

})
.factory('SubjectService',function(){
  _math=new Array();
  _literature = new Array();
  _science = new Array();
  _humanity = new Array();
  _language = new Array();
  return{
    setMath:function(m){_math = m;},
    setLit:function(m){_literature = m;},
    setSci:function(m){_science = m;},
    setHum:function(m){_humanity = m;},
    setLan:function(m){_language = m;},

    getSubject : function(){
      subject = {};
      subject.math = _math;
      subject.literature = _literature;
      subject.science = _science;
      subject.humanity = _humanity;
      subject.language = _language;
      return subject;
    }
  };
})

.factory('Query',function(){

  _query={};
  _query.subject = "";
  _query.service="";
  _query.problem="";
  _query.period=new Array();
  return{
    GetQuery: function(){return _query;},
    SetQuery:function(q){_query = q;},
    reset:function(){
      _query={};
      _query.subject = "";
      _query.problem="";
      _query.service="";
      _query.period=new Array();
    }
  };

})


.factory('TutorInfo',function(){
  tutorinfo = {};
  tutorinfo.subject = new Array();
  tutorinfo.subsubjects=new Array();
  tutorinfo.Status = new Array();
  tutorinfo.credentials = new Array();
  tutorinfo.periods = new Array();
  return {
    getTutorInfo: function(){
      return tutorinfo;
    },
    setTutorInfo:function(tutor){
      tutorinfo = tutor;
    },
    IsAva:function(){
      var bool = true;
      for (i=0; i<tutorinfo.Status.length;i++){
        if(tutorinfo.Status[i]!="True"){
          bool = false;
        }
      }
      if(bool){return "Available";}
      else{return "Pending";}
    }



  };
})

.factory('Requests',function(){
  request = {};
  request.subject = "";

  return {
    getRequest: function () {
      return request;
    },
    setRequest: function (authObject) {
      request = authObject;
    }
  };

})



.service('BlankService', [function(){

}]);


var LoginoutService = angular.module('LoginoutService',['app.services','ionic',"SyncService"])

.service('UserService', ['$q', 'KinveyConfiguration', '$kinvey','Cred',"$state","$ionicPopup", "$timeout","DataBase","TutorInfo",
function($q, KinveyConfiguration, $kinvey,Cred,$state,$ionicPopup,$timeout,DataBase,TutorInfo) {

  var initialized = false;

  return {
    /**
    *
    * @returns {*}
    */
    ResetInit:function(){
      initialized = false;
    },




    getCurrent:function(){
      var d = $q.defer();
      var activeUser = $kinvey.User.getActiveUser();
      var promise = $q.resolve(activeUser);
      if (activeUser !== null) {
        promise = activeUser.me();
        promise.then(function(activeUser) {
          return activeUser;
        });
      }else{
        return null;
      }

    },


    init: function() {
      try {
        var d = $q.defer();




        function getTheUser() {
          var d = $q.defer();
          var activeUser = $kinvey.User.getActiveUser();
          var promise = $q.resolve(activeUser);
          if (activeUser !== null) {
            promise = activeUser.me();
          }
          promise.then(function(currentUser) {
            if(currentUser!==null){
              cred = {};
              console.log(currentUser);
              cred.name = currentUser.data.name;
              cred.email = currentUser.data.email;
              cred.login = true;
              cred.grade = currentUser.data.grade;
              cred.Tutor = currentUser.data.tutor;
              cred.User = currentUser.data.user;
              Cred.setCred(cred);
              return d.resolve(currentUser);
            }else{
              return d.reject({
                error: "noUser"
              });
            }

          }, function(err) {
            return d.reject({
              error: "noUser"
            });
          });
          return d.promise;
        }



        console.log("in init");
        // if initialized, then return the activeUser
        if (initialized === false) {
          // Initialize Kinvey
          $kinvey.initialize(KinveyConfiguration).then(function() {
            initialized = true;
            console.log("in init: initialized");
            return getTheUser();
          })
          .then(function(_user) {
            if(_user!==undefined){
              console.log("in init got user: ", _user);
              cred = {};
              cred.name = _user.data.name;
              cred.email = _user.data.email;
              cred.login = true;
              cred.grade = _user.data.grade;
              cred.Tutor = _user.data.tutor;
              cred.User = _user.data.user;
              Cred.setCred(cred);
              if(_user.data.tutor){
                //          FetchTInfo();
              }
              return d.resolve(_user);
            }else{
              Cred.reset();
              $state.go("login");
              return d.reject({
                error: "noUser",
                kinveyError: err
              });
            }
          }, function(err) {
            console.log("in init error: ", err);
            Cred.reset();
            $state.go("login");
            return d.reject({
              error: "noUser",
              kinveyError: err
            });
          });
          return d.promise;
        } else {
          return getTheUser();
        }
      } catch (EE) {
        console.log(EE)
      }
    },
    /**
    *
    * @param none
    * @returns initialized
    */
    FetchTInfo:function(){

      var tutorservice =  $kinvey.DataStore.collection('TutorService');
      var activeUser = $kinvey.User.getActiveUser();
      var promise = $q.resolve(activeUser);
      if (activeUser !== null) {
        promise = activeUser.me();
      }
      promise.then(function(activeUser) {
        var query = new $kinvey.Query();
        query.contains('tutorid', String(activeUser._id));
        console.log(query);
        var datacollection = new Array();
        var steam = tutorservice.find(query);
        steam.subscribe(function onNext(data) {
          console.log(data);

          datacollection.add(data);
        }, function onError(error) {
          console.log(error);
        }, function onComplete() {
          tutorinfo = {};
          console.log("tutorinfo")
          tutorinfo.subject = new Array();
          tutorinfo.subsubjects=new Array();
          tutorinfo.Status = new Array();
          tutorinfo.periods = new Array();
          tutorinfo.credentials = new Array();
          for (i =0; i<datacollection.length;i++){
            tutorinfo.subject.add(datacollection[i].subject);
            tutorinfo.subsubject.add(datacollection[i].subsubjects);
            tutorinfo.Status.add(datacollection[i].Status);
            tutorinfo.periods.add(datacollection[i].periods);
            tutorinfo.credentials.add(datacollection[i].credentials);
          }
          console.log(tutorinfo);
          tutorinfo.setTutorInfo(tutorinfo);
        });
      }).catch(function(error) {
        console.log(error);
      });
    },



    InitOnly:function(_subject){
      var d = $q.defer();
      if (initialized === false) {
        // Initialize Kinvey
        $kinvey.initialize(KinveyConfiguration).then(function() {
          initialized = true;
          console.log("initialized")
          d.resolve();
        })
        .then(function() {

          return d.resolve();
        }, function(err) {
          console.log("in init error: ", err);
          Cred.reset();
          $state.go("login");
          return d.reject({
            error: "noUser",
            kinveyError: err
          });
        });
        return d.promise;
      } else {
        d.resolve();
        return d.promise;
      }

    },

    checkInit: function() {
      return initialized;
    },

    /**
    *
    * @param _userParams
    */


    createUser: function(_email,_tutor,_user,_password,_name,_grade) {
      var promise = $kinvey.User.signup({
        username : _email,
        email:_email,
        tutor : _tutor,
        user:_user,
        password : _password,
        name: _name,
        grade : _grade
      });
      return promise;
    },
    /**
    *
    * @param _parseInitUser
    * @returns {Promise}
    */
    currentUser: function(_parseInitUser) {

      // if there is no user passed in, see if there is already an
      // active user that can be utilized
    },
    /**
    *
    * @param _user
    * @param _password
    * @returns {Promise}
    */
    login: function(_user, _password) {
      /*var promise = $kinvey.User.login({
      username: _user,
      password: _password
    });
    promise.then(function(user){
    cred = {};
    cred.name = user.data.name;
    cred.email = user.data.email;
    cred.login = true;
    cred.grade = user.data.grade;
    cred.Tutor = user.data.tutor;
    cred.User = user.data.user;
    Cred.setCred(cred);
    return user;
  }).catch(function(error){
  alert("Error log in "+error);
});*/

return $kinvey.User.login({
  username: _user,
  password: _password
});
},
/**
*
* @returns {Promise}
*/

reset: function(){
  $ionicPopup.prompt({
    title: 'Enter your Email Address',
    inputType: 'email',
    okText: "Reset Password!",
    cancelType:"button-positive"
  }).then(function(email) {
    if(email!=null && email!=undefined){
      var promise = $kinvey.User.resetPassword(email);
      promise = promise.then(function onSuccess() {
        alert("Sent Successfully");
      }).catch(function onError(error) {
        alert(error);
      });

    }
  });
},
logout: function(_callback) {

  var defered = $q.defer();

  var user = $kinvey.User.getActiveUser();
  if (null !== user) {
    $kinvey.User.logout().then(function onSuccess() {
      Cred.reset();
      $state.go("login");
      console.log("logged out", user);
    }).catch(function onError(error) {
      console.log("Error: logged out", error);
    });
  }
}

}
}
]);



var SyncService = angular.module('SyncService',['app.services'])

.service('DataBase', ['$q', 'KinveyConfiguration', '$kinvey','Cred',"$state","TutorInfo","SubjectService",
function($q, KinveyConfiguration, $kinvey,Cred,$state,TutorInfo,SubjectService) {



  return {
    /**
    *
    * @returns {*}
    */
    CompareSubject:function(_s1,_s2){
      return true;
    },


    CreateTutorAccount: function(_subject,_credentials,_period){
      var backservice =  $kinvey.DataStore.collection('BackService', $kinvey.DataStoreType.Network);
      var tutorservice =  $kinvey.DataStore.collection('TutorService', $kinvey.DataStoreType.Network);

      var promise = tutorservice.save({
        subject :_subject,
        subsubjects:"",
        credentials:_credentials,
        periods:_period,
        Status:"Pending"

      }).then(function onSuccess(entity){
        console.log(entity);
        tutorinfo = {};
        tutorinfo.subject = "";
        tutorinfo.subsubjects=new Array();
        tutorinfo.Status = "";
        tutorinfo.credentials="";

        console.log("success create Tutor account ",entity);
      }).catch(function onError(error){
        console.log("Fail "+error);
      });


    },

    FetchTutorInfo:function(_subject,_subsubject,_period){
      var TutorList = new Array();
      var query = new $kinvey.Query();
      var stream = backservice.find(query);
      query.equalTo("subject",_subject);
      stream.subscribe(function onNext(entities) {
        var subsubject = entitles.subsubjects;
        var periodstring = entitles.periods.split(",");
        var periodbool = false;

      }, function onError(error) {
        console.log("Error"+error);
      }, function onComplete() {

      });

    }

  }
}
]);
