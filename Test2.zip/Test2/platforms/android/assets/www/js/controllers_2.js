angular.module('app.controllers', ['ngImgCrop', 'LoginoutService', 'SyncService', "ionic", 'ngFileUpload'])

.controller('homeCtrl', ['$ionicLoading', '$ionicPopup', 'KinveyConfiguration', '$kinvey', '$scope', '$stateParams', 'Cred', '$state', 'UserService', 'DataBase', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function($ionicLoading, $ionicPopup, KinveyConfiguration, $kinvey, $scope, $stateParams, Cred, $state, UserService, DataBase) {
    var activeUser;
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'

      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };
    $kinvey.initialize(KinveyConfiguration).then(function() {
      $scope.showLoading();
      activeUser = $kinvey.User.getActiveUser();
      if (activeUser != null) {

        var cred = {};

        cred.name = activeUser.data.name;
        cred.email = activeUser.data.email;
        cred.login = true;
        cred.grade = activeUser.data.grade;
        cred.Tutor = activeUser.data.tutor;
        cred.User = activeUser.data.user;
        Cred.setCred(cred);
        //$state.go("menu.home",{},{reload:true});
        $scope.hideLoading();
      } else {
        $scope.hideLoading();
        $state.go("login");
      }

    });
    $scope.cred = function() {
      return Cred.getCred();
    }
    $scope.announcement = "Welcome to 2TR!";
    $scope.session1 = "No upcoming sessions."

    $scope.AddSession = function() {
      if (Cred.getCred().login === false) {
        alert("Please Log in First!");
        $state.go("login");
      } else {
        $state.go("menu.pickASubject");
      }
    }

    $scope.ViewSessions = function() {
      if (Cred.getCred().login === false) {
        alert("Please Log in First!");
        $state.go("login");
      } else {
        $state.go("menu.status", {}, {
          reload: true
        });
      }
    }
    $scope.showPopup = function() {
      $scope.data = {};

      // An elaborate, custom popup
      var myPopup = $ionicPopup.show({
        template: 'Date:(exp.1/12/2017)<input type="data" ng-model="data.date">Time(Minutes):<input type="number" ng-model="data.time">Student Tutee Name:<input type="text" ng-model="data.name">Subject:<label class="item item-select e"><select  style="color:#FFFFFF" ng-model="data.subject"><option  style="color:#FFFFFF">Math</option><option  style="color:#FFFFFF">Science</option><option  style="color:#FFFFFF">Literature</option><option  style="color:#FFFFFF">Humanity</option><option  style="color:#FFFFFF">Language</option><option  style="color:#FFFFFF">Other</option></label>',
        title: 'Enter Date, Time and Student tutee name',
        subTitle: 'Please fill in completely',
        cssClass: 'PopupSubmit',
        scope: $scope,
        buttons: [{
          type: 'button-positive',
          text: 'Cancel'
        }, {
          text: '<b>Save</b>',
          type: 'button-positive',
          onTap: function(e) {
            if ($scope.data.subject != undefined && $scope.data.date != undefined && $scope.data.time != undefined && $scope.data.name != undefined) {
              var dataStore = $kinvey.DataStore.collection('tutorHour');
              $scope.showLoading();
              var promise = dataStore.save({
                tutor_id: activeUser._id,
                subject: $scope.data.subject,
                date: $scope.data.date,
                time: $scope.data.time,
                tutee_name: $scope.data.name
              }).then(function onSuccess(entity) {
              }).catch(function onError(error) {
                alert(console.error);
              });
              $scope.hideLoading();
            } else {
              alert("Please fill in completely!");
            }

          }
        }]
      });

    }

    $scope.submitTime = function() {
      $scope.showPopup();
    }

  }
])

.controller('menuCtrl', ['$ionicLoading', '$kinvey', '$scope', '$stateParams', '$state', 'Cred', 'UserService', 'TutorInfo', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function($ionicLoading, $kinvey, $scope, $stateParams, $state, Cred, UserService, TutorInfo) {
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'

      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };
    $scope.showLoading();
    UserService.init().then(function(_s) {
      $scope.hideLoading();
    });

    $scope.cred = function() {
      return Cred.getCred();
    }
    $scope.ava = function() {
      return TutorInfo.IsAva();
    }

    if ($scope.cred().login === false) {
      $scope.name = "Guest";
      $scope.grade = "";
      $scope.ShowUser = true;
      $scope.ShowTutor = false;
    } else {
      $scope.name = $scope.cred().name;
      $scope.grade = $scope.cred().grade;
    }

    $scope.login = $scope.cred().login;
    $scope.AddTutor = function() {
      $state.go("tutorSignUp");
    }
    $scope.AddSession = function() {
      if (Cred.getCred().login === false) {
        alert("Please Log in First!");
        $state.go("login");
      } else {
        // Loged in
        $state.go("menu.pickASubject");


      }
    }
    $scope.home = function() {
      window.location.href = "";
    }
    $scope.ViewSessions = function() {
      if (Cred.getCred().login === false) {
        alert("Please Log in First");
        $state.go("login");
      } else {
        $state.go("menu.status", {}, {
          reload: true
        });


      }
    }
    $scope.Signup = function() {
      $state.go('welcomeTo2TR');
    }
    $scope.Login = function() {
      $state.go('login');
    }

    $scope.Logout = function() {
      $state.go("login");
      UserService.logout();
      Cred.reset();

    }
    $scope.setting = function() {
      $state.go('menu.profileSettings');
    }

  }
])

.controller('welcomeTo2TRCtrl', ['$ionicLoading', '$scope', '$stateParams', 'UserService', '$state', 'Cred', 'DataBase', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function($ionicLoading, $scope, $stateParams, UserService, $state, Cred, DataBase) {
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'

      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };
    $scope.cred = {
      ViewUser: false,
      ViewTutor: false,
      email: "@lyndoninstitute.org",
      password: "",
      name: "",
      grade: ""
    };
    UserService.InitOnly();
    $scope.registerPass = false;
    $scope.check = function() {
      registerPass = false;

      if (($scope.cred.email == "")) {
        alert("Please Use the right Email Address!");
      } else if ($scope.cred.name == "") {
        alert("Please Enter Your Full name.");
      } else if ($scope.cred.password == "") {
        alert("Please Enter Your Password.")
      } else if ($scope.cred.grade == "") {
        alert("Please Select Your Grade.");
      } else if ($scope.cred.email.split('@')[1] != "lyndoninstitute.org") {
        alert("Please Use Lyndoninstitute Email.");

      } else {
        $scope.registerPass = true;
      }
    }


    $scope.TutorSignup = function() {
      $scope.check();
      if ($scope.registerPass) {
        $scope.showLoading();
        UserService.createUser($scope.cred.email, $scope.cred.ViewTutor, $scope.cred.ViewUser, $scope.cred.password, $scope.cred.name, $scope.cred.grade).then(function(_response) {
    
          alert("login success " + _response.data.name);
          creden = {};
          creden.name = _response.data.name;
          creden.email = _response.data.username;
          creden.Tutor = _response.data.tutor;
          creden.User = _response.data.user;
          creden.grade = _response.data.grade;
          creden.login = true;
          Cred.setCred(creden);
          $scope.hideLoading();
          $state.go('tutorSignUp');
        }, function(_error) {

          $scope.hideLoading();
          alert("error logging in " + _error.description);
        });
      }
    };

    $scope.UserSignup = function() {
      $scope.check();
      if ($scope.registerPass) {
        $scope.showLoading();
        UserService.createUser($scope.cred.email, $scope.cred.ViewTutor, $scope.cred.ViewUser, $scope.cred.password, $scope.cred.name, $scope.cred.grade).then(function(_response) {
   
          alert("login success " + _response.data.name);
          cred = {};
          creden = {};
          creden.name = _response.data.name;
          creden.email = _response.data.username;
          creden.Tutor = _response.data.tutor;
          creden.User = _response.data.user;
          creden.grade = _response.data.grade;
          creden.login = true;
          Cred.setCred(creden);
          $scope.hideLoading();
          $state.go('menu.home');
        }, function(_error) {
          $scope.hideLoading();
          alert("error logging in " + _error+",Please Email us.");
        });
      }
    };


  }
])

.controller('loginCtrl', ['$ionicLoading', 'KinveyConfiguration', '$kinvey', '$scope', '$stateParams', '$state', 'Cred', 'UserService', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function($ionicLoading, KinveyConfiguration, $kinvey, $scope, $stateParams, $state, Cred, UserService) {
    //UserService.init();
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'
      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };
    $scope.isDisabled = false;
    $kinvey.initialize(KinveyConfiguration).then(function() {
      var activeUser = $kinvey.User.getActiveUser();
      if (activeUser != null) {
        $state.go("menu.home");
      }

    });
    $scope.creds = {
      username: "@lyndoninstitute.org",
      password: ""
    };

    $scope.login = function() {
      $scope.showLoading();
      $scope.isDisabled = true;
      if (Cred.getCred().login) {
        $state.go("menu.home");
      }
      //UserService.login($scope.creds.username, $scope.creds.password)

      var promise = $kinvey.User.login({
        username: $scope.creds.username,
        password: $scope.creds.password
      });
      promise.then(function(_response) {
        cred = {};
        cred.name = _response.name;
        cred.email = _response.username;
        cred.Tutor = _response.tutor;
        cred.User = _response.user;
        cred.grade = _response.grade;
        cred.login = true;
        Cred.setCred(cred);
        $scope.hideLoading();
        // transition to next state
        $state.go("menu.home", {}, {
          reload: true
        });
      }).catch(function(error) {
        alert(error.message);
        $scope.hideLoading();
        $scope.isDisabled = false;
      });



    };

    $scope.signup = function() {
      $state.go('welcomeTo2TR');
    };


    $scope.forget = function() {
      UserService.reset();
    };

  }
])

.controller('pickASubjectCtrl', ['$scope', '$stateParams', '$state', 'Requests', 'UserService', "DataBase", // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName


  function($scope, $stateParams, $state, Requests, UserService, DataBase) {
    //UserService.init();


    $scope.mathbutton = function() {

      r = {};
      r.subject = "Math";
      r.subsubject = "";
      Requests.setRequest(r);

      $state.go("menu.completeTheRequestForm", {}, {
        reload: true
      });



    };

    $scope.humanitybutton = function() {

      r = {};
      r.subject = "Humanity";
      r.subsubject = "";
      Requests.setRequest(r);
      $state.go("menu.completeTheRequestForm", {}, {
        reload: true
      });
    };
    $scope.literaturebutton = function() {
      r = {};
      r.subject = "Literature";
      r.subsubject = "";
      Requests.setRequest(r);
      $state.go("menu.completeTheRequestForm", {}, {
        reload: true
      });
    };
    $scope.sciencebutton = function() {
      r = {};
      r.subject = "Science";
      r.subsubject = "";
      Requests.setRequest(r);
      $state.go("menu.completeTheRequestForm", {}, {
        reload: true
      });
    };
    $scope.languagebutton = function() {
      r = {};
      r.subject = "Language";
      r.subsubject = "";
      Requests.setRequest(r);
      $state.go("menu.completeTheRequestForm", {}, {
        reload: true
      });
    };
    $scope.otherbutton = function() {
      r = {};
      r.subject = "Other";
      r.subsubject = "";
      Requests.setRequest(r);
      $state.go("menu.completeTheRequestForm", {}, {
        reload: true
      });
    };


  }
])

.controller('tutorSignUpCtrl', ['$http', '$ionicPopup', '$timeout', 'Upload', 'KinveyConfiguration', '$kinvey', '$scope', '$stateParams', 'UserService', 'DataBase', '$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function($http, $ionicPopup, $timeout, Upload, KinveyConfiguration, $kinvey, $scope, $stateParams, UserService, DataBase, $state) {
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'
      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };

    $scope.pic = {};

    if (window.File && window.FileReader && window.FileList && window.Blob) {
      // Great success! All the File APIs are supported.
    } else {
      alert('The File APIs are not fully supported.');
    }
    $scope.back = function() {
      $state.go("menu.home", {}, {
        reload: true
      });
    }

    var activeUser;
    $kinvey.initialize(KinveyConfiguration).then(function() {
      activeUser = $kinvey.User.getActiveUser();
      $scope.info.first = "";
      $scope.info.second = "";
      $scope.info.third = "";
      $scope.info.othersubject_one = "";
      $scope.info.othersubject_two = "";
      $scope.info.othersubject_thr = "";
      $scope.info.cred_one = "";
      $scope.info.cred_two = "";
      $scope.info.cred_thr = "";

    });

    $scope.info = {};


    $scope.check = function() {

      if ($scope.info.first == "") {
        alert("Please fill the subject!");
        return false;
      } else if (($scope.info.first == 'Other' && $scope.info.othersubject_one == "") || ($scope.info.second == 'Other' && $scope.info.othersubject_two == "") || ($scope.info.third == 'Other' && $scope.info.othersubject_thr == "")) {
        alert("Please type in your subject!");
        return false;
      } else if (($scope.info.first != "" && $scope.info.cred_one == "") || ($scope.info.second != "" && $scope.info.cred_two == "") || ($scope.info.third != "" && $scope.info.cred_thr == "")) {
        alert("Please type in the credentials of you are able to tutor that subject!");
        return false;
      } else if (!($scope.info.period_0 || $scope.info.period_1 || $scope.info.period_2 || $scope.info.period_3 || $scope.info.period_4 || $scope.info.period_5 || $scope.info.period_6 || $scope.info.period_7 || $scope.info.period_8 || $scope.info.period_9)) {
        alert("Please choose the available time.");
        return false;
      } else {
        return true;
      }
    }
    $scope.isDisabled = false;
    $scope.showConfirm = function() {
      var confirmPopup = $ionicPopup.confirm({
        cssClass: 'confirmwindow',
        title: 'Tutor Sign Up',
        cancelText: 'back',
        okText: 'Confirm',
        template: 'By confirm this message you are agreeing with the honor code and become a 2Tr Tutor. Do you wish to continue?'

      });
      confirmPopup.then(function(res) {
        if (res) {


          if ($scope.pic.picFile != undefined && $scope.pic.picFile != null) {
            //$scope.pic.picFile.$ngfBlobUrl = $scope.pic.croppedDataUrl;
            var filee = Upload.dataUrltoBlob($scope.pic.croppedDataUrl, $scope.pic.picFile.name)

            var returnfile;
            var metadata = {
              filename: filee.name,
              mimeType: filee.type,
              _acl: {
                "gr": true,
                "creater": activeUser._id
              },
              public: true,
              size: filee.size,
              tutor_name:activeUser.email
            };
            var promise = $kinvey.Files.upload(filee, metadata)
              .then(function(file) {
                returnfile = file._id;


                var tutor = {};
                tutor.first = {};
                tutor.second = {};
                tutor.third = {};
                var period = new Array();

                if ($scope.info.first != null) {
                  tutor.first.subject = $scope.info.first;
                  tutor.first.subsubjects = "";
                  if ($scope.info.first == 'Other') {
                    tutor.first.subsubjects = $scope.info.othersubject_one;
                  }
                  tutor.first.cred = $scope.info.cred_one;
                }
                if ($scope.info.second != null) {
                  tutor.second.subject = $scope.info.second;
                  tutor.second.subsubjects = "";
                  if ($scope.info.second == 'Other') {
                    tutor.second.subsubjects = $scope.info.othersubject_two;
                  }
                  tutor.second.cred = $scope.info.cred_two;
                }
                if ($scope.info.third != null) {
                  tutor.third.subject = $scope.info.third;
                  tutor.third.subsubjects = "";
                  if ($scope.info.third == 'Other') {
                    tutor.third.subsubjects = $scope.info.othersubject_thr;
                  }
                  tutor.third.cred = $scope.info.cred_thr;
                }
                if ($scope.info.period_0) {
                  period.push('0');
                }
                if ($scope.info.period_1) {
                  period.push('1');
                }
                if ($scope.info.period_2) {
                  period.push('2');
                }
                if ($scope.info.period_3) {
                  period.push('3');
                }
                if ($scope.info.period_4) {
                  period.push('4');
                }
                if ($scope.info.period_5) {
                  period.push('5');
                }
                if ($scope.info.period_6) {
                  period.push('6');
                }
                if ($scope.info.period_7) {
                  period.push('7');
                }
                if ($scope.info.period_8) {
                  period.push('8');
                }
                if ($scope.info.period_9) {
                  period.push('9');
                }
                tutor.period = period;

                var tutorservice = $kinvey.DataStore.collection('TutorService', $kinvey.DataStoreType.Network);
                var tutoremail = "";
                var tutorid = "";
                var grade_t = "";
                var email = "";
                if (activeUser != null) {
                  tutoremail = activeUser.data.name;
                  tutorid = activeUser._id;
                  grade_t = activeUser.data.grade;
                  email = activeUser.email;
                }
                if (tutor.first.subject != "") { //First
                  var promise = tutorservice.save({
                    subject: tutor.first.subject,
                    subsubjects: tutor.first.subsubjects,
                    credentials: tutor.first.cred,
                    periods: tutor.period,
                    Status: "False",
                    tutor_email: email,
                    grade: grade_t,
                    Email: tutoremail,
                    tutorid: tutorid,
                    profile: returnfile,
                    Status: "Pending",
                    IsOpen: true

                  }).then(function onSuccess(entity) {
                    //alert("Successfully saved.");
                  }).catch(function onError(error) {
                    alert("Error saved " + error);
                  });
                }
                if (tutor.second.subject != "") { //Second
                  var promise = tutorservice.save({
                    subject: tutor.second.subject,
                    subsubjects: tutor.second.subsubjects,
                    credentials: tutor.second.cred,
                    periods: tutor.period,
                    Status: "False",
                    Email: tutoremail,
                    tutor_email: email,
                    grade: grade_t,
                    tutorid: tutorid,
                    profile: returnfile,
                    Status: "Pending",
                    IsOpen: true

                  }).then(function onSuccess(entity) {
                    //alert("Successfully saved.");
                  }).catch(function onError(error) {
                    alert("Error saved " + error);
                  });
                }
                if (tutor.third.subject != "") { //Third
                  var promise = tutorservice.save({
                    subject: tutor.third.subject,
                    subsubjects: tutor.third.subsubjects,
                    credentials: tutor.third.cred,
                    periods: tutor.period,
                    Status: "False",
                    Email: tutoremail,
                    tutor_email: email,
                    grade: grade_t,
                    tutorid: tutorid,
                    profile: returnfile,
                    Status: "Pending",
                    IsOpen: true

                  }).then(function onSuccess(entity) {
                    //  alert("Successfully saved.");
                  }).catch(function onError(error) {
                    alert("Error saved " + error);
                  });
                }


                alert("Successfully saved.");
                $http.put("baas.kinvey.com/user/kid_r1LNZMGSx/" + activeUser._id, {
                    tutor: true
                  })
                  .success(function(data, status, headers, config) {})
                  .error(function(data, status, header, config) {});
                $state.go("menu.home");
              })
              .catch(function(error) {
              });

          } else {



            var tutor = {};
            tutor.first = {};
            tutor.second = {};
            tutor.third = {};
            var period = new Array();

            if ($scope.info.first != null) {
              tutor.first.subject = $scope.info.first;
              tutor.first.subsubjects = "";
              if ($scope.info.first == 'Other') {
                tutor.first.subsubjects = $scope.info.othersubject_one;
              }
              tutor.first.cred = $scope.info.cred_one;
            }
            if ($scope.info.second != null) {
              tutor.second.subject = $scope.info.second;
              tutor.second.subsubjects = "";
              if ($scope.info.second == 'Other') {
                tutor.second.subsubjects = $scope.info.othersubject_two;
              }
              tutor.second.cred = $scope.info.cred_two;
            }
            if ($scope.info.third != null) {
              tutor.third.subject = $scope.info.third;
              tutor.third.subsubjects = "";
              if ($scope.info.third == 'Other') {
                tutor.third.subsubjects = $scope.info.othersubject_thr;
              }
              tutor.third.cred = $scope.info.cred_thr;
            }
            if ($scope.info.period_0) {
              period.push('0');
            }
            if ($scope.info.period_1) {
              period.push('1');
            }
            if ($scope.info.period_2) {
              period.push('2');
            }
            if ($scope.info.period_3) {
              period.push('3');
            }
            if ($scope.info.period_4) {
              period.push('4');
            }
            if ($scope.info.period_5) {
              period.push('5');
            }
            if ($scope.info.period_6) {
              period.push('6');
            }
            if ($scope.info.period_7) {
              period.push('7');
            }
            if ($scope.info.period_8) {
              period.push('8');
            }
            if ($scope.info.period_9) {
              period.push('9');
            }
            tutor.period = period;

            var tutorservice = $kinvey.DataStore.collection('TutorService', $kinvey.DataStoreType.Network);
            var tutoremail = "";
            var tutorid = "";
            var grade_t = "";
            var email = "";
            if (activeUser != null) {
              tutoremail = activeUser.data.name;
              tutorid = activeUser._id;
              grade_t = activeUser.data.grade;
              email = activeUser.email;
            }
            if (tutor.first.subject != "") { //First
              var promise = tutorservice.save({
                subject: tutor.first.subject,
                subsubjects: tutor.first.subsubjects,
                credentials: tutor.first.cred,
                periods: tutor.period,
                Status: "False",
                Email: tutoremail,
                tutor_email: email,
                grade: grade_t,
                tutorid: tutorid,
                profile: "",
                Status: "Pending",
                IsOpen: true

              }).then(function onSuccess(entity) {
                //alert("Successfully saved.");
              }).catch(function onError(error) {
                alert("Error saved " + error);
              });
            }
            if (tutor.second.subject != "") { //Second
              var promise = tutorservice.save({
                subject: tutor.second.subject,
                subsubjects: tutor.second.subsubjects,
                credentials: tutor.second.cred,
                periods: tutor.period,
                Status: "False",
                Email: tutoremail,
                tutorid: tutorid,
                tutor_email: email,
                grade: grade_t,
                profile: "",
                Status: "Pending",
                IsOpen: true

              }).then(function onSuccess(entity) {
              }).catch(function onError(error) {
                alert("Error saved " + error);
              });
            }
            if (tutor.third.subject != "") { //Third
              var promise = tutorservice.save({
                subject: tutor.third.subject,
                subsubjects: tutor.third.subsubjects,
                credentials: tutor.third.cred,
                periods: tutor.period,
                Status: "False",
                Email: tutoremail,
                tutorid: tutorid,
                profile: "",
                tutor_email: email,
                grade: grade_t,
                Status: "Pending",
                IsOpen: true

              }).then(function onSuccess(entity) {
              }).catch(function onError(error) {
                alert("Error saved " + error);
              });
            }


            alert("Successfully saved.");
            $http.put("baas.kinvey.com/user/kid_r1LNZMGSx/" + activeUser._id, {
                tutor: true
              })
              .success(function(data, status, headers, config) {})
              .error(function(data, status, header, config) {});
            $state.go("menu.home");


          }
        } else {
          $scope.isDisabled = false;
        }
      });
    };


    $scope.tutorSignUp = function() {
      $scope.isDisabled = true;
      if ($scope.check()) {
        $scope.showConfirm();
      } else {
        $scope.isDisabled = false;
      }
    }
  }
])

.controller('findYourTutorCtrl', ['$q', '$http', '$ionicLoading', '$kinvey', '$scope', '$stateParams', 'UserService', 'Requests', 'Query', "$ionicSlideBoxDelegate", // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function($q, $http, $ionicLoading, $kinvey, $scope, $stateParams, UserService, Requests, Query, $ionicSlideBoxDelegate) {
    var authString = "Basic " + "a2lkX3IxTE5aTUdTeDo3OTI4MWI3MGEzYzI0ZTI5YWU0MWJkNzBlNjE2Mzk2ZQ==";
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'

      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };
    $scope.profile = {};
    $scope.info = {
      request: true,
      show: true
    };
    $scope.info.profile = new Array();

    $scope.subject = function() {
      return Requests.getRequest().subject;
    };


    UserService.InitOnly();
    $scope.showLoading();
 
    $scope.profileLoad=function() {
      var r = $scope.datacollection;
      if (r.length > 0) {
        for (i = 0; i <r.length; i++) {
          if (r[i].profile != "") {
            $http({
              method: "GET",
              url: 'https://baas.kinvey.com/blob/kid_r1LNZMGSx/' + r[i].profile,
              headers: {
                "Authorization": authString
              }
            }).then(function mySucces(response) {
              $scope.profile[response.data.tutor_name] = response.data._downloadURL;
            }, function myError(response) {
            });
          }
        }
      }
    }


    $scope.$on("$ionicSlides.sliderInitialized", function(event, data) {
      // data.slider is the instance of Swiper

      $scope.slider = data.slider;
      var slide = document.getElementById("findYourTutor-slide27");
      $scope.activeIndex = 0;
    });


    $scope.$on("$ionicSlides.slideChangeEnd", function(event, data) {

      $scope.activeIndex = data.slider.activeIndex;

    });



    var dataStore = $kinvey.DataStore.collection('TutorService');

    var _q = Query.GetQuery();
    if (_q.subject == "") {
      $scope.info.show = false;
      $scope.hideLoading();
    }
    var query = new $kinvey.Query();
    query.contains('periods', _q.period).equalTo('subject', _q.subject).equalTo('Status', "Available").contains('subsubjects', _q.service);

    $scope.datacollection = [];

    dataStore.find(query).subscribe(function(data) {
      $scope.datacollection = data;
      if (data == null) {
        $scope.info.show = false;
        $scope.hideLoading();
      } else {
        $scope.showLoading();
        $scope.info.show = true;
        $scope.profile = {};
      }
    }, function(error) {
      $scope.hideLoading();
    }, function() {
      $scope.profileLoad();

      if ($scope.datacollection == null) {
        $scope.info.show = false;
        $scope.hideLoading();
      }

       var r = $scope.datacollection;
      if (r.length > 0) {
        for (i = 0; i <r.length; i++) {
          if (r[i].profile == ""|| r[i].profile===undefined) {
               $scope.profile[r[i].tutor_email] = "http://storage.googleapis.com/5e3e09d2e2254f0c9cb9fd1bd20af744/cca793b6-c83b-45c2-9bd0-5665d5edd757/logo.png";
          }
        }
      }


      $ionicSlideBoxDelegate.update();
      $scope.hideLoading();

    });

    $scope.request = function() {
      $scope.info.request = false;
      var activeUser = $kinvey.User.getActiveUser();
      var database = $kinvey.DataStore.collection('tutorsession');
      var promise = database.save({
        "tutor": $scope.datacollection[$scope.activeIndex].tutor_email,
        "user": activeUser.email,
        "subject": "Tutor Request Notification[2Tr -LI Peer Tutor]",
        "body": String(Query.GetQuery().problem),
        "request_subject": Query.GetQuery().subject,
        "request_period": String(Query.GetQuery().period),
        "request_service": Query.GetQuery().service
      }).then(function onSuccess(entity) {
        alert("Sent Successfully!");
        window.location.href = "";
      }).catch(function onError(error) {
        $scope.info.request = true;
      });


    }

    $scope.request_null = function() {
      var activeUser = $kinvey.User.getActiveUser();
      console.log($scope.datacollection[$scope.activeIndex]);
      var database = $kinvey.DataStore.collection('tutorsession');
      var promise = database.save({
        "tutor": "2tr@Lyndoninstitute.org",
        "user": "",
        "subject": "(No Tutor found) Tutor Request Notification[2Tr -LI Peer Tutor]",
        "body": String(Query.GetQuery().problem)
      }).then(function onSuccess(entity) {
        window.location.href = "";
      }).catch(function onError(error) {
        window.location.href = "";
      });


    }

  }
])

.controller('statusCtrl', ['$ionicLoading', '$ionicPopup', '$kinvey', '$scope', '$stateParams', 'UserService', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function($ionicLoading, $ionicPopup, $kinvey, $scope, $stateParams, UserService) {
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'

      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };
    $scope.showLoading();
    UserService.init().then(function(_u) {
      $scope.info = {};
      $scope.info.show = false;
      $scope.info.show2 = false;
      $scope.request = new Array();
      $scope.receive = new Array();

      var dataStore = $kinvey.DataStore.collection('tutorsession');
      var query = new $kinvey.Query();
      var activeUser = $kinvey.User.getActiveUser();
      query.equalTo('user', activeUser.data.email);
      var datacollection = "";

      dataStore.find(query).subscribe(function(data) {
        datacollection = data;
      }, function(error) {
        alert(error);
      }, function() {
        if (datacollection == null) {
          $scope.info.show = true;
        } else {
          for (i = 0; i < datacollection.length; i++) {
            $scope.request.push({
              date: datacollection[i]._kmd.lmt.split('T')[0],
              subject: datacollection[i].request_subject,
              period: datacollection[i].request_period,
              service: datacollection[i].request_service,
              name: datacollection[i].tutor.split('@')[0]
            });
          }


        }
        $scope.hideLoading()
      });

      if (activeUser.data.tutor) {
        var query = new $kinvey.Query();
        var activeUser = $kinvey.User.getActiveUser();
        query.equalTo('tutor', activeUser.data.email);
        var datacollection = "";
        dataStore.find(query).subscribe(function(data) {
          datacollection = data;
        }, function(error) {
          alert(error);
        }, function() {
          if (datacollection == null) {
            $scope.info.show2 = true;
          } else {
            $scope.info.show2 = false;
            for (i = 0; i < datacollection.length; i++) {
              $scope.receive.push({
                date: datacollection[i]._kmd.lmt.split('T')[0],
                subject: datacollection[i].request_subject,
                period: datacollection[i].request_period,
                service: datacollection[i].request_service,
                name: datacollection[i].user.split('@')[0]
              });
            }
            $scope.info.tutorshow = true;

          }
        });
        $scope.hideLoading()
      } else {
        $scope.info.tutorshow = false;
        $scope.hideLoading();
      }

    });

    $scope.feedback = function(index) {
      alert("Function Coming Soon.")


    }


  }
])


.controller('profileSettingsCtrl', ['Upload', '$ionicLoading', '$state', 'KinveyConfiguration', '$q', '$kinvey', '$scope', '$stateParams', 'UserService', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function(Upload, $ionicLoading, $state, KinveyConfiguration, $q, $kinvey, $scope, $stateParams, UserService) {
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'

      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };
    $scope.returnfile = "";
    $scope.datacollection = "";
    $scope.password_new = "";
    $scope.info = {};
    $scope.pic = {};
    $scope.pic.show = false;
    $scope.doRefresh = function() {

      $kinvey.initialize(KinveyConfiguration).then(function() {
        $scope.showLoading();
        var dataStore = $kinvey.DataStore.collection('TutorService');
        var activeUser = $kinvey.User.getActiveUser();
        if (activeUser != null) {
          if (activeUser.data.tutor === true) {

            var query = new $kinvey.Query();
            query.equalTo('tutor_email', activeUser.email);

            dataStore.find(query).subscribe(function(data) {
              $scope.datacollection = data;
            }, function(error) {
              $scope.hideLoading();
            }, function() {
              if (datacollection.length > 0) {
                var promise = $kinvey.Files.stream($scope.datacollection[0].profile)
                  .then(function(file) {
                    $scope.pic.src = (file._downloadURL);
                  })
                  .catch(function(error) {
                    $scope.hideLoading();
                  });
              }
            });



            $scope.info.Istutor = true;
            $scope.info.grade = activeUser.data.grade;
            $scope.info.Email = activeUser.data.name;
            $scope.info.tutorid = activeUser.data.tutorid;
            $scope.info.tutoremail = activeUser.email;

            var query = new $kinvey.Query();
            var datacollection;
            query.equalTo('Email', activeUser.data.name);
            dataStore.find(query).subscribe(function(data) {
              datacollection = data;
            }, function(error) {
              alert("Fail " + error);
              $scope.hideLoading();
            }, function() {
              var ava = "";
              if (datacollection.length > 0) {
                $scope.info.first_id = datacollection[0]._id;
                $scope.info.first = datacollection[0].subject;
                $scope.info.cred_one = datacollection[0].credentials;
                $scope.info.subsubjects_1 = datacollection[0].subsubjects;
                $scope.info.status_1 = datacollection[0].Status;
                $scope.returnfile = datacollection[0].profile;
                //document.getElementById("firstava").checked =  datacollection[0].isOpen;
                $scope.info.firstava = datacollection[0].IsOpen;
                if (datacollection[0].Status == "Pending") {
                  ava += "Subject 1 "
                }
              }
              if (datacollection.length > 1) {
                $scope.info.second_id = datacollection[1]._id;
                $scope.info.second = datacollection[1].subject;
                $scope.info.cred_two = datacollection[1].credentials;
                $scope.info.subsubjects_2 = datacollection[1].subsubjects;
                $scope.info.status_2 = datacollection[1].Status;
                //document.getElementById("secondava").checked =  datacollection[1].isOpen;
                $scope.info.secondava = datacollection[1].IsOpen;
                if (datacollection[1].Status == "Pending") {
                  ava += "Subject 2 "
                }
              }
              if (datacollection.length > 2) {
                $scope.info.third_id = datacollection[2]._id;
                $scope.info.third = datacollection[2].subject;
                $scope.info.cred_thr = datacollection[2].credentials;
                $scope.info.subsubjects_3 = datacollection[2].subsubjects;
                $scope.info.status_3 = datacollection[2].Status;
                //document.getElementById("thirdava").checked =  datacollection[2].isOpen;
                $scope.info.thirdava = datacollection[2].IsOpen;
                if (datacollection[2].Status == "Pending") {
                  ava += "Subject 3 "
                }
              }
              if (ava == "") {
                $scope.info.ava = "All subjects are available.";
              } else if (ava.length > 10) {
                $scope.info.ava = ava + "are pending.";
              } else {
                $scope.info.ava = ava + "is pending.";
              }
              var period = datacollection[0].periods;
              if (period.indexOf('0') != -1) {
                $scope.info.p0 = true;
              }
              if (period.indexOf('1') != -1) {
                $scope.info.p1 = true;
              }
              if (period.indexOf('2') != -1) {
                $scope.info.p2 = true;
              }
              if (period.indexOf('3') != -1) {
                $scope.info.p3 = true;
              }
              if (period.indexOf('4') != -1) {
                $scope.info.p4 = true;
              }
              if (period.indexOf('5') != -1) {
                $scope.info.p5 = true;
              }
              if (period.indexOf('6') != -1) {
                $scope.info.p6 = true;
              }
              if (period.indexOf('7') != -1) {
                $scope.info.p7 = true;
              }
              if (period.indexOf('8') != -1) {
                $scope.info.p8 = true;
              }
              if (period.indexOf('9') != -1) {
                $scope.info.p9 = true;
              }
              $scope.hideLoading();
            });


          } else {
            $scope.info.Istutor = false;
            $scope.hideLoading();
          }
          // $scope.hideLoading();
        } else {
          $scope.hideLoading();
          $state.go('login');
        }
      });
      $scope.$broadcast('scroll.refreshComplete');
    }

    $kinvey.initialize(KinveyConfiguration).then(function() {
      $scope.showLoading();
      var dataStore = $kinvey.DataStore.collection('TutorService');
      var activeUser = $kinvey.User.getActiveUser();
      if (activeUser != null) {
        if (activeUser.data.tutor === true) {

          var query = new $kinvey.Query();
          query.equalTo('tutor_email', activeUser.email);

          dataStore.find(query).subscribe(function(data) {
            $scope.datacollection = data;
          }, function(error) {
            $scope.hideLoading();
          }, function() {
            if (datacollection.length > 0) {
              var promise = $kinvey.Files.stream($scope.datacollection[0].profile)
                .then(function(file) {
                  $scope.pic.src = (file._downloadURL);
                })
                .catch(function(error) {
                  $scope.hideLoading();
                });
            }
          });



          $scope.info.Istutor = true;
          $scope.info.grade = activeUser.data.grade;
          $scope.info.Email = activeUser.data.name;
          $scope.info.tutorid = activeUser.data.tutorid;
          $scope.info.tutoremail = activeUser.email;

          var query = new $kinvey.Query();
          var datacollection;
          query.equalTo('Email', activeUser.data.name);
          dataStore.find(query).subscribe(function(data) {
            datacollection = data;
          }, function(error) {
            alert("Fail " + error);
            $scope.hideLoading();
          }, function() {
            var ava = "";
            if (datacollection.length > 0) {
              $scope.info.first_id = datacollection[0]._id;
              $scope.info.first = datacollection[0].subject;
              $scope.info.cred_one = datacollection[0].credentials;
              $scope.info.subsubjects_1 = datacollection[0].subsubjects;
              $scope.info.status_1 = datacollection[0].Status;
              $scope.returnfile = datacollection[0].profile;
              //document.getElementById("firstava").checked =  datacollection[0].isOpen;
              $scope.info.firstava = datacollection[0].IsOpen;
              if (datacollection[0].Status == "Pending") {
                ava += "Subject 1 "
              }
            }
            if (datacollection.length > 1) {
              $scope.info.second_id = datacollection[1]._id;
              $scope.info.second = datacollection[1].subject;
              $scope.info.cred_two = datacollection[1].credentials;
              $scope.info.subsubjects_2 = datacollection[1].subsubjects;
              $scope.info.status_2 = datacollection[1].Status;
              //document.getElementById("secondava").checked =  datacollection[1].isOpen;
              $scope.info.secondava = datacollection[1].IsOpen;
              if (datacollection[1].Status == "Pending") {
                ava += "Subject 2 "
              }
            }
            if (datacollection.length > 2) {
              $scope.info.third_id = datacollection[2]._id;
              $scope.info.third = datacollection[2].subject;
              $scope.info.cred_thr = datacollection[2].credentials;
              $scope.info.subsubjects_3 = datacollection[2].subsubjects;
              $scope.info.status_3 = datacollection[2].Status;
              //document.getElementById("thirdava").checked =  datacollection[2].isOpen;
              $scope.info.thirdava = datacollection[2].IsOpen;
              if (datacollection[2].Status == "Pending") {
                ava += "Subject 3 "
              }
            }
            if (ava == "") {
              $scope.info.ava = "All subjects are available.";
            } else if (ava.length > 10) {
              $scope.info.ava = ava + "are pending.";
            } else {
              $scope.info.ava = ava + "is pending.";
            }
            var period = datacollection[0].periods;
            if (period.indexOf('0') != -1) {
              $scope.info.p0 = true;
            }
            if (period.indexOf('1') != -1) {
              $scope.info.p1 = true;
            }
            if (period.indexOf('2') != -1) {
              $scope.info.p2 = true;
            }
            if (period.indexOf('3') != -1) {
              $scope.info.p3 = true;
            }
            if (period.indexOf('4') != -1) {
              $scope.info.p4 = true;
            }
            if (period.indexOf('5') != -1) {
              $scope.info.p5 = true;
            }
            if (period.indexOf('6') != -1) {
              $scope.info.p6 = true;
            }
            if (period.indexOf('7') != -1) {
              $scope.info.p7 = true;
            }
            if (period.indexOf('8') != -1) {
              $scope.info.p8 = true;
            }
            if (period.indexOf('9') != -1) {
              $scope.info.p9 = true;
            }
            $scope.hideLoading();
          });


        } else {
          $scope.info.Istutor = false;
          $scope.hideLoading();
        }
        // $scope.hideLoading();
      } else {
        $scope.hideLoading();
        $state.go('menu.home');
      }
    });

    $scope.saveProfile = function() {
      $scope.showLoading();


      if ($scope.pic.picFile != undefined && $scope.pic.picFile != null) {

        var promise = $kinvey.Files.removeById($scope.datacollection[0].profile);
        var activeUser = $kinvey.User.getActiveUser();

        $scope.pic.picFile.$ngfBlobUrl = $scope.pic.croppedDataUrl;
        var file = Upload.dataUrltoBlob($scope.pic.croppedDataUrl, $scope.pic.picFile.name)
        var metadata = {
          filename: file.name,
          mimeType: file.type,
          _acl: {
            "gr": true,
            "creater": activeUser._id
          },
          public: true,
          size: file.size,
          tutor_name:activeUser.email
        };
        var promise = $kinvey.Files.upload(file, metadata)
          .then(function(file) {
            $scope.returnfile = file._id;



            var period = new Array();
            if ($scope.info.p0) {
              period.push("0");
            }
            if ($scope.info.p1) {
              period.push('1');
            }
            if ($scope.info.p2) {
              period.push('2');
            }
            if ($scope.info.p3) {
              period.push('3');
            }
            if ($scope.info.p4) {
              period.push('4');
            }
            if ($scope.info.p5) {
              period.push('5');
            }
            if ($scope.info.p6) {
              period.push('6');
            }
            if ($scope.info.p7) {
              period.push('7');
            }
            if ($scope.info.p8) {
              period.push('8');
            }
            if ($scope.info.p9) {
              period.push('9');
            }
            var dataStore = $kinvey.DataStore.collection('TutorService');
            if ($scope.info.first_id != undefined) {
              var promise = dataStore.save({
                _id: $scope.info.first_id,
                grade: $scope.info.grade,
                subject: $scope.info.first,
                subsubjects: $scope.info.subsubjects_1,
                Status: $scope.info.status_1,
                Email: $scope.info.Email,
                tutorid: $scope.info.tutorid,
                credentials: $scope.info.cred_one,
                IsOpen: $scope.info.firstava,
                tutor_email: $scope.info.tutoremail,
                profile: $scope.returnfile,
                periods: period
              }).then(function onSuccess(entity) {
              }).catch(function onError(error) {
                alert("Fail " + error);
              });
            }
            if ($scope.info.second_id != undefined) {
              var promise = dataStore.save({
                _id: $scope.info.second_id,
                credentials: $scope.info.cred_two,
                grade: $scope.info.grade,
                IsOpen: $scope.info.secondava,
                subject: $scope.info.second,
                subsubjects: $scope.info.subsubjects_2,
                Status: $scope.info.status_2,
                tutor_email: $scope.info.tutoremail,
                Email: $scope.info.Email,
                tutorid: $scope.info.tutorid,
                profile: $scope.returnfile,
                periods: period
              }).then(function onSuccess(entity) {
              }).catch(function onError(error) {
                alert("Fail " + error);
              });
            }
            if ($scope.info.third_id != undefined) {
              var promise = dataStore.save({
                _id: $scope.info.third_id,
                credentials: $scope.info.cred_thr,
                grade: $scope.info.grade,
                IsOpen: $scope.info.thirdava,
                subject: $scope.info.third,
                tutor_email: $scope.info.tutoremail,
                subsubjects: $scope.info.subsubjects_3,
                Status: $scope.info.status_3,
                profile: $scope.info.profile,
                Email: $scope.info.Email,
                tutorid: $scope.returnfile,
                periods: period
              }).then(function onSuccess(entity) {
              }).catch(function onError(error) {
                alert("Fail " + error);
              });

            }
          });


        $scope.hideLoading();
        $scope.doRefresh();

      } else {



        var period = new Array();
        if ($scope.info.p0) {
          period.push("0");
        }
        if ($scope.info.p1) {
          period.push('1');
        }
        if ($scope.info.p2) {
          period.push('2');
        }
        if ($scope.info.p3) {
          period.push('3');
        }
        if ($scope.info.p4) {
          period.push('4');
        }
        if ($scope.info.p5) {
          period.push('5');
        }
        if ($scope.info.p6) {
          period.push('6');
        }
        if ($scope.info.p7) {
          period.push('7');
        }
        if ($scope.info.p8) {
          period.push('8');
        }
        if ($scope.info.p9) {
          period.push('9');
        }

        var dataStore = $kinvey.DataStore.collection('TutorService');
        if ($scope.info.first_id != undefined) {
          var promise = dataStore.save({
            _id: $scope.info.first_id,
            grade: $scope.info.grade,
            subject: $scope.info.first,
            subsubjects: $scope.info.subsubjects_1,
            Status: $scope.info.status_1,
            Email: $scope.info.Email,
            tutorid: $scope.info.tutorid,
            credentials: $scope.info.cred_one,
            IsOpen: $scope.info.firstava,
            tutor_email: $scope.info.tutoremail,
            profile: $scope.returnfile,
            periods: period
          }).then(function onSuccess(entity) {
          }).catch(function onError(error) {
            alert("Fail " + error);
          });
        }
        if ($scope.info.second_id != undefined) {
          var promise = dataStore.save({
            _id: $scope.info.second_id,
            credentials: $scope.info.cred_two,
            grade: $scope.info.grade,
            IsOpen: $scope.info.secondava,
            subject: $scope.info.second,
            subsubjects: $scope.info.subsubjects_2,
            Status: $scope.info.status_2,
            tutor_email: $scope.info.tutoremail,
            Email: $scope.info.Email,
            tutorid: $scope.info.tutorid,
            profile: $scope.returnfile,
            periods: period
          }).then(function onSuccess(entity) {
          }).catch(function onError(error) {
            alert("Fail " + error);
          });
        }
        if ($scope.info.third_id != undefined) {
          var promise = dataStore.save({
            _id: $scope.info.third_id,
            credentials: $scope.info.cred_thr,
            grade: $scope.info.grade,
            IsOpen: $scope.info.thirdava,
            subject: $scope.info.third,
            tutor_email: $scope.info.tutoremail,
            subsubjects: $scope.info.subsubjects_3,
            Status: $scope.info.status_3,
            profile: $scope.info.profile,
            Email: $scope.info.Email,
            tutorid: $scope.returnfile,
            periods: period
          }).then(function onSuccess(entity) {
          }).catch(function onError(error) {
            alert("Fail " + error);
          });

        }


        $scope.hideLoading();
        $scope.doRefresh();
      }


    }



    $scope.changePW = function() {
      $scope.showLoading();
      var promise = $q(function(resolve) {
        resolve($kinvey.User.getActiveUser());
      });
      promise.then(function(user) {
        var promise = $kinvey.User.resetPassword(user.email);
        promise = promise.then(function onSuccess() {
          $scope.hideLoading();
          alert("Reset Email Sent Successfully! Please check your Lyndoninstitute.org Email");
        }).catch(function onError(error) {
          $scope.hideLoading();
          alert(error);
        });
      });
    }

    $scope.ProfilePic = function() {
      $scope.pic.show = true;

    }
  }

])

.controller('completeTheRequestFormCtrl', ['$ionicLoading', 'Query', '$kinvey', 'KinveyConfiguration', '$scope', '$stateParams', '$state', 'Requests', 'UserService', 'DataBase', "SubjectService", // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
  // You can include any angular dependencies as parameters for this function
  // TIP: Access Route Parameters for your page via $stateParams.parameterName
  function($ionicLoading, Query, $kinvey, KinveyConfiguration, $scope, $stateParams, $state, Requests, UserService, DataBase, SubjectService) {
    //UserService.init();
    $scope.showLoading = function() {
      $ionicLoading.show({
        template: '<p><ion-spinner icon="bubbles" class="button-block spinner-assertive"></ion-spinner><a style="color:white">Loading....</a></p>'

      });
    };
    $scope.hideLoading = function() {
      $ionicLoading.hide().then(function() {
      });
    };
    $scope.info = {};
    $scope.info.problem = "";
    $scope.back = function() {
      window.location.href = "";
    }
    $scope.subject = function() {
      return Requests.getRequest().subject;
    };
    $scope.showLoading();
    $kinvey.initialize(KinveyConfiguration).then(function() {});
    if ($scope.subject() == "") {
      $scope.hideLoading();
      $state.go('menu.home', {}, {
        reload: true
      });
    }
    var backservice = $kinvey.DataStore.collection('BackService', $kinvey.DataStoreType.Network);
    var query = new $kinvey.Query();
    query.contains("Subject", "Math");
    var steam = backservice.find(query);
    var datacollection = "";
    steam.subscribe(function onNext(data) {
      datacollection = data;
    }, function onError(error) {
    }, function onComplete() {
      var d = datacollection[0].Service.split(",");
      for (i = 0; i < d.length; i++) {
        var x = document.createElement("OPTION");
        var select = document.getElementById("mathselect");
        x.text = d[i];
        x.style.color = "#FFFFFF";
        select.appendChild(x);
      }
    });
    var query = new $kinvey.Query();
    query.contains("Subject", "Literature");
    var steam = backservice.find(query);
    var datacollection = "";
    steam.subscribe(function onNext(data) {
      datacollection = data;
    }, function onError(error) {
    }, function onComplete() {
      var d = datacollection[0].Service.split(",");
      for (i = 0; i < d.length; i++) {
        var x = document.createElement("OPTION");
        var select = document.getElementById("literatureselect");
        x.text = d[i];
        x.style.color = "#FFFFFF";
        select.appendChild(x);
      }
    });
    var query = new $kinvey.Query();
    query.contains("Subject", "Science");
    var steam = backservice.find(query);
    var datacollection = "";
    steam.subscribe(function onNext(data) {
      datacollection = data;
    }, function onError(error) {
    }, function onComplete() {
      var d = datacollection[0].Service.split(",");
      for (i = 0; i < d.length; i++) {
        var x = document.createElement("OPTION");
        var select = document.getElementById("scienceselect");
        x.text = d[i];
        x.style.color = "#FFFFFF";
        select.appendChild(x);
      }
    });
    var query = new $kinvey.Query();
    query.contains("Subject", "Humanity");
    var steam = backservice.find(query);
    var datacollection = "";
    steam.subscribe(function onNext(data) {
      datacollection = data;
    }, function onError(error) {
    }, function onComplete() {
      var d = datacollection[0].Service.split(",");
      for (i = 0; i < d.length; i++) {
        var x = document.createElement("OPTION");
        var select = document.getElementById("humanityselect");
        x.text = d[i];
        x.style.color = "#FFFFFF";
        select.appendChild(x);
      }
    });
    var query = new $kinvey.Query();
    query.contains("Subject", "Language");
    var steam = backservice.find(query);
    var datacollection = "";
    steam.subscribe(function onNext(data) {
      datacollection = data;
    }, function onError(error) {
    }, function onComplete() {
      var d = datacollection[0].Service.split(",");
      for (i = 0; i < d.length; i++) {
        var x = document.createElement("OPTION");
        var select = document.getElementById("languageselect");
        x.text = d[i];
        x.style.color = "#FFFFFF";
        select.appendChild(x);
      }
      $scope.hideLoading();
    });

    $scope.findTutor = function() {
      var _q = {};
      _q.subject = $scope.subject();
      _q.service = $scope.info.services;
      _q.problem = $scope.info.problem;
      _q.period = new Array();
      if ($scope.info.PZero) {
        _q.period.push('0');
      }
      if ($scope.info.POne) {
        _q.period.push('1');
      }
      if ($scope.info.PTwo) {
        _q.period.push('2');
      }
      if ($scope.info.PThree) {
        _q.period.push('3');
      }
      if ($scope.info.PFour) {
        _q.period.push('4');
      }
      if ($scope.info.PFive) {
        _q.period.push('5');
      }
      if ($scope.info.PSix) {
        _q.period.push('6');
      }
      if ($scope.info.PSeven) {
        _q.period.push('7');
      }
      if ($scope.info.PEight) {
        _q.period.push('8');
      }
      if ($scope.info.PNine) {
        _q.period.push('9');
      }
      if (_q.subject != '' && _q.service != '' && _q.problem != "" && ($scope.info.PZero || $scope.info.POne || $scope.info.PTwo || $scope.info.PThree || $scope.info.PFour || $scope.info.PFive || $scope.info.PSix || $scope.info.PSeven || $scope.info.PEight || $scope.info.PNine)) {
        Query.SetQuery(_q);
        $state.go("menu.findYourTutor", {}, {
          reload: true
        });
      } else {
        alert('Please Fill in the subject, periods or problem description.')
      }
    }

  }
]);